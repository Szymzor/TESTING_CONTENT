# encoding: utf-8
a = "Ogórek";
b = "Cebula";
c = "Pomidor"

string = a+b+c