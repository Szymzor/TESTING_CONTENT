# encoding: utf-8
string = 'Idzie Grześ przez wieś i nic nie niesie'
puts string.count("ś")