# encoding: utf-8
p string = 'Idzie Grześ przez wieś i nic nie niesie'.length