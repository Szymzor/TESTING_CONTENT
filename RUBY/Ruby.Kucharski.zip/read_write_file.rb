=begin
file_content = File.open("text_file.txt") 
arr = []
file_content.each_char {|char| 
	arr<<char
} 

arr = arr.join("").to_s.chomp.reverse
File.write('text_file.txt', arr)
file_content.close

=end

#OR



filecontent = File.read('text_file.txt')
filecontent = filecontent.chomp.reverse
File.write('text_file.txt', filecontent)
