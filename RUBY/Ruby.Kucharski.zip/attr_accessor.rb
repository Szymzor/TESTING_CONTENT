class Class
	attr_accessor :name
	
	def initialize
		@name = "Szymon_one" 
	end

end

run_class = Class.new
run_class.instance_variable_set(:@name, "Szymon_two")
run_class.name = "Szymon_three"
puts run_class.name #=> skrypt zwróci ostatnią wartość "Szymon_three"

#jak widać w tym przykładzie zmienną instancji (@name) można nadpisać w wyniku:
#1) umieszczenia zmiennej instancji w metodzie initialize (w obrębie klasy)
#2) za pomocą metody ".instance_variable_set(:@value, "wartosc")"" praktycznie w dowolnym miejscu kodu poza klasą
#3) za pomocą bezpośredniego przypisania zmiennej (do której mamy dostęp za pomocą accessora)