class Class2
	attr_reader :name2

	def initialize
		@name2 = "Szymon_1"  #Najpierw zmienna instancji "@name2" jest ustawiana na "Szymon_1"
	end
end

klasa2 = Class2.new
klasa2.instance_variable_set(:@name2, "Szymon_2")	#W drugiej kolejności ta sama zmienna ustawiana jest na "Szymon_2"
puts klasa2.name2 #=> Skrypt zwróci ostatnią wartość "Szymon_2"

#Dwie pierwsze zasady z powyższego punktu dotyczą także attr_reader