# encoding: utf-8
arr = 'Idzie Grześ przez wieś i nic nie niesie'.split(" ")
print arr