class Klasa
	def ==(cokolwiek) 
		@cokolwiek = cokolwiek
	end
end

run = Klasa.new
p run == 7